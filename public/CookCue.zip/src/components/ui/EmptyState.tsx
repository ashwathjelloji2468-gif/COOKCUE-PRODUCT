import React from "react";
import { cn } from "@/lib/utils";
import { Inbox } from "lucide-react";

export interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  action?: React.ReactNode;
  className?: string;
}

export function EmptyState({
  icon = <Inbox className="w-10 h-10 text-muted-foreground" />,
  title,
  description,
  action,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        "rounded-xl border border-dashed border-[var(--card-border)] bg-[var(--card)] p-12 text-center flex flex-col items-center justify-center max-w-lg mx-auto",
        className
      )}
    >
      <div className="rounded-full bg-[var(--accent-soft)] p-4 text-[var(--accent)] mb-4">
        {icon}
      </div>
      <h3 className="font-heading font-semibold text-[var(--foreground)] text-lg mb-1">
        {title}
      </h3>
      <p className="text-sm text-[var(--muted)] max-w-sm mb-6 leading-relaxed">
        {description}
      </p>
      {action && <div>{action}</div>}
    </div>
  );
}
