import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-semibold transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 cursor-pointer select-none hover:shadow-md hover:-translate-y-0.5 hover:scale-[1.02] active:translate-y-0 active:scale-[0.98]",
  {
    variants: {
      variant: {
        default:
          "bg-[#193D32] dark:bg-[#2b634e] text-white shadow-xs hover:bg-[#122c24] dark:hover:bg-[#34785e] hover:shadow-emerald-950/20",
        destructive:
          "bg-rose-600 text-white shadow-xs hover:bg-rose-700 hover:shadow-rose-900/20",
        outline:
          "border-2 border-[var(--card-border)] bg-[var(--card)] text-[var(--foreground)] hover:border-[#193D32]/50 dark:hover:border-emerald-500/50 hover:bg-[var(--accent-soft)] hover:text-[var(--foreground)]",
        secondary:
          "bg-[var(--accent-soft)] text-[var(--foreground)] border border-[var(--card-border)] hover:bg-[#d8e6dc] dark:hover:bg-[#233f31]",
        ghost:
          "hover:bg-[var(--accent-soft)] hover:text-[var(--foreground)] hover:scale-100 hover:-translate-y-0 shadow-none hover:shadow-none",
        link:
          "text-[var(--accent)] underline-offset-4 hover:underline shadow-none hover:shadow-none hover:scale-100 hover:-translate-y-0",
        subtle:
          "bg-[var(--accent-soft)] text-[var(--foreground)] border border-[var(--accent)]/30 hover:border-[var(--accent)]/60 hover:bg-[#d8e6dc] dark:hover:bg-[#233f31]",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-lg px-6",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
