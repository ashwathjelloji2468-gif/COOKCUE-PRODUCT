"use client";

import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";

export function ThemeToggle() {
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <button
        type="button"
        className="w-9 h-9 rounded-xl border border-[var(--card-border)] bg-[var(--card)] flex items-center justify-center"
        aria-label="Toggle theme"
      />
    );
  }

  const isDark = resolvedTheme === "dark";

  return (
    <button
      type="button"
      onClick={() => setTheme(isDark ? "light" : "dark")}
      className="w-9 h-9 rounded-xl border border-[var(--card-border)] bg-[var(--card)] hover:bg-[var(--accent-soft)] hover:scale-105 hover:shadow-xs active:scale-95 flex items-center justify-center transition-all cursor-pointer"
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
    >
      {isDark ? (
        <Sun className="w-4 h-4 text-[var(--foreground)]" />
      ) : (
        <Moon className="w-4 h-4 text-[var(--foreground)]" />
      )}
    </button>
  );
}
