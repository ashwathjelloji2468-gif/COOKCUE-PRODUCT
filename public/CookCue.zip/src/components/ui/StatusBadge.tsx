import React from "react";
import { cn } from "@/lib/utils";
import {
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  HelpCircle,
  Check,
  Edit3,
  Power,
  PowerOff,
} from "lucide-react";

export type StatusType =
  | "eligible"
  | "stockout"
  | "abnormal"
  | "missing"
  | "approved"
  | "overridden"
  | "active"
  | "inactive";

interface StatusBadgeProps {
  status: StatusType;
  label?: string;
  className?: string;
}

const statusConfig: Record<
  StatusType,
  {
    defaultLabel: string;
    icon: React.ReactNode;
    classes: string;
  }
> = {
  eligible: {
    defaultLabel: "Eligible",
    icon: <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-emerald-800 dark:text-emerald-300" />,
    classes: "bg-emerald-50 text-emerald-800 border-emerald-300/80 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800 font-semibold",
  },
  stockout: {
    defaultLabel: "Stockout",
    icon: <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-red-700 dark:text-red-300" />,
    classes: "bg-red-50 text-red-700 border-red-300/80 dark:bg-red-950/40 dark:text-red-300 dark:border-red-800 font-medium",
  },
  abnormal: {
    defaultLabel: "Abnormal",
    icon: <AlertCircle className="w-3.5 h-3.5 shrink-0 text-amber-800 dark:text-amber-300" />,
    classes: "bg-amber-50 text-amber-800 border-amber-300/80 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800 font-medium",
  },
  missing: {
    defaultLabel: "Missing Data",
    icon: <HelpCircle className="w-3.5 h-3.5 shrink-0 text-stone-600 dark:text-stone-300" />,
    classes: "bg-stone-100 text-stone-700 border-stone-300/80 dark:bg-stone-900/60 dark:text-stone-300 dark:border-stone-700 font-normal",
  },
  approved: {
    defaultLabel: "Approved",
    icon: <Check className="w-3.5 h-3.5 shrink-0 text-emerald-900 dark:text-emerald-200" />,
    classes: "bg-emerald-100 text-emerald-900 border-emerald-300 dark:bg-emerald-900/50 dark:text-emerald-200 dark:border-emerald-700 font-semibold",
  },
  overridden: {
    defaultLabel: "Adjusted",
    icon: <Edit3 className="w-3.5 h-3.5 shrink-0 text-blue-800 dark:text-blue-300" />,
    classes: "bg-blue-50 text-blue-800 border-blue-300/80 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800 font-semibold",
  },
  active: {
    defaultLabel: "Active",
    icon: <Power className="w-3.5 h-3.5 shrink-0 text-emerald-800 dark:text-emerald-300" />,
    classes: "bg-emerald-50 text-emerald-800 border-emerald-300/80 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800 font-semibold",
  },
  inactive: {
    defaultLabel: "Inactive",
    icon: <PowerOff className="w-3.5 h-3.5 shrink-0 text-stone-600 dark:text-stone-400" />,
    classes: "bg-stone-100 text-stone-600 border-stone-300/80 dark:bg-stone-900/60 dark:text-stone-400 dark:border-stone-700 font-normal",
  },
};

export function StatusBadge({ status, label, className }: StatusBadgeProps) {
  const config = statusConfig[status];

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-[11px] tracking-tight transition-colors shadow-2xs",
        config.classes,
        className
      )}
    >
      {config.icon}
      <span>{label || config.defaultLabel}</span>
    </span>
  );
}
