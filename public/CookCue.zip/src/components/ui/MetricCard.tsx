import React from "react";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";

export interface MetricCardProps {
  label: string;
  value: string | number;
  unit?: string;
  delta?: {
    value: string | number;
    label?: string;
    isPositive?: boolean;
  };
  icon?: React.ReactNode;
  status?: "normal" | "warning" | "danger" | "success";
  className?: string;
}

export function MetricCard({
  label,
  value,
  unit,
  delta,
  icon,
  status = "normal",
  className,
}: MetricCardProps) {
  const statusBorderClasses = {
    normal: "border-[var(--card-border)] bg-[var(--card)]",
    warning: "border-amber-500/40 bg-amber-500/10 text-amber-900 dark:text-amber-200",
    danger: "border-rose-500/40 bg-rose-500/10 text-rose-900 dark:text-rose-200",
    success: "border-[var(--accent)]/30 bg-[var(--accent-soft)]",
  }[status];

  return (
    <Card
      className={cn(
        "p-5 sm:p-6 flex flex-col justify-between transition-all duration-150 hover:border-[var(--card-border)] hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 rounded-xl",
        statusBorderClasses,
        className
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[var(--muted)]">
          {label}
        </span>
        {icon && (
          <div className="h-8 w-8 rounded-lg bg-[var(--accent-soft)] border border-[var(--card-border)] flex items-center justify-center text-[var(--accent)] shrink-0">
            {icon}
          </div>
        )}
      </div>

      <div className="mt-4">
        <div className="flex items-baseline gap-2">
          <span className="text-3xl sm:text-4xl font-bold font-heading text-[var(--foreground)] tabular-nums tracking-tight">
            {value}
          </span>
          {unit && (
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--muted)]">
              {unit}
            </span>
          )}
        </div>

        {delta && (
          <p className="mt-2 text-[11px] text-muted-foreground flex items-center gap-1.5 font-medium">
            <span
              className={cn(
                "font-semibold tabular-nums px-1.5 py-0.5 rounded text-[10px]",
                delta.isPositive ? "bg-[#D9EF79]/30 text-[#193D32]" : "bg-[#FDEAE5] text-[#C24A30]"
              )}
            >
              {delta.value}
            </span>
            {delta.label && <span>{delta.label}</span>}
          </p>
        )}
      </div>
    </Card>
  );
}
